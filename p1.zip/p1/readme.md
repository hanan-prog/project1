**Command to compile on MacOS with M1 chip**

`clang++ -Wall squareStarter.cpp -xc glad/glad.c -F /Library/Frameworks -framework SDL3 -Wl,-rpath,/Library/Frameworks -o square`




